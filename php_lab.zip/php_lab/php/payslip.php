<html> 
<body> 
<form method="POST" action=""> 
Name: <input type="text" 
name="name"><br> 
Basic Salary: <input type="text" 
name="basic"><br> 
Designation: 
<select name="designation"> 
<option 
value="Manager">Manager</option> 
<option 
value="Supervisor">Supervisor</option> 
<option value="Clerk">Clerk</option> 
<option value="Peon">Peon</option> 
</select><br> 
<input type="submit" value="Generate 
Payslip"> 
</form> 
<?php 
if ($_POST) { 
$name = $_POST['name']; 
$basicSalary = $_POST['basic']; 
$designation = $_POST['designation']; 
switch ($designation) { 
case 'Manager': 
$conveyance = 1000; 
$extraAllowance = 500; 
break; 
case 'Supervisor': 
$conveyance = 750; 
$extraAllowance = 200; 
break; 
case 'Clerk': 
$conveyance = 500; 
$extraAllowance = 100; 
break; 
case 'Peon': 
$conveyance = 250; 
break; 
}
$gross = $basicSalary + 0.25 * 
$basicSalary + $conveyance + 
$extraAllowance; 
if ($gross <= 2500) { 
$incomeTax = 0; 
} elseif ($gross <= 4000) { 
$incomeTax = 0.03 * $gross; 
} elseif ($gross <= 5000) { 
$incomeTax = 0.05 * $gross; 
} else { 
$incomeTax = 0.08 * $gross; 
} 
$net = $gross - $incomeTax; 
echo "<br>\n"; 
echo "Employee Name: $name<br>"; 
echo "Basic Salary: $basicSalary<br>"; 
echo "Designation: $designation<br>"; 
echo "Conveyance: $conveyance<br>"; 
echo "Extra Allowance: 
$extraAllowance<br>"; 
echo "Gross Salary: $gross<br>"; 
echo "Income Tax: $incomeTax<br>"; 
echo "Net Salary: $net<br>"; 
} 
?> 
</body> 
</html> 