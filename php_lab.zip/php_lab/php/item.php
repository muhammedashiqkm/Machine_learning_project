<html> 
<body> 
<center>List of Products</center> 
<form method="POST" action=""> 
Item Code: <input type="text" 
name="icode"><br> 
Item Name:<input type="text" 
name="iname"><br> 
Unit Price: <input type="text" 
name="iprice"><br> 
<input type="submit" value="Display"> 
</form> 
</body> 
</html> 

<?php 
if ($_POST) { 
$no = $_POST['icode']; 
$name = $_POST['iname']; 
$price = $_POST['iprice']; 
$con = pg_connect("host=localhost 
dbname=college user=postgres 
password=root"); 
if ($con) { 
echo "Successfully Connected........"; 
$qry = "insert into product (itemcode, 
itemname, unitprice) values ($no, 
'$name', $price)"; 
$result = pg_query($con, $qry); 
$qry1 = "select * from product"; 
$result1 = pg_query($con, $qry1); 
echo "<table border=1>"; 
echo "<tr><th>Item Code</th><th>Item 
Name</th><th>Unit Price</th></tr>"; 
while ($row = pg_fetch_row($result1)) { 
echo "<tr> 
<td>$row[0]</td> 
<td>$row[1]</td> 
<td>$row[2]</td> 
</tr>"; 
} 
echo "</table>"; 
} 
} 
?>

