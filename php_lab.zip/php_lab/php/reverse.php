<?php 
if ($_POST) { 
function reverseString($str) { 
$length=strlen($str); 
for($i=($length-1);$i>=0;$i--) 
echo $str[$i]; 
} 
$String = $_POST['str']; 
reverseString($String); 
} ?> 
