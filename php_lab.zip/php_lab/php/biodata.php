<?php
if ($_POST) {
echo "Name:".$_POST["name"]."<br>";
echo
"Address:".$_POST["address"]."<br>";
echo "Age:".$_POST["age"]."<br>";
echo "Mobile:".$_POST["mobile"]."<br>";
echo
"Qualification:".$_POST["qualification"]."
<br>";
echo "Email:".$_POST["email"]."<br>";
}
?>