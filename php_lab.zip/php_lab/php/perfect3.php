<?php 
if ($_POST) { 
$no = $_POST["number"]; 
$sum=0; 
for($i=1;$i<$no;$i++) 
{ 
if($no % $i==0) 
$sum=$sum+$i; 
}   
if ($sum == $no) 
echo "perfect number."; 
elseif ($sum > $no) 
echo " is an abundant number"; 
else 
echo " is a deficient number"; 
} 
?> 