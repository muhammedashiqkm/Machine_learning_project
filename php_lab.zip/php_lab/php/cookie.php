<html> 
<body> 
<?php 
//date_default_timezone_set('Asia/Kolkata
//'); 
if(isset($_COOKIE['lastVisit'])) { 
$lastVisit = $_COOKIE['lastVisit']; 
echo "Your last visit was: " . $lastVisit; 
} else { 
echo "This is your first visit!"; }
$inTwoMonths = 60 * 60 * 24 * 60 + 
time(); 
setcookie('lastVisit', date("G:i - d/m/y"), 
$inTwoMonths); 
?> 
</body> 
</html> 