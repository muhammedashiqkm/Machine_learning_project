<html> 
<body> 
<center>Bank Transactions</center> 
<form method="POST" action=""> 
Account Number: <input type="text" 
name="acc"><br> 
Amount: <input type="text" 
name="amnt"><br> 
Transaction Type: 
<input type="radio" name="trans" 
value="deposit"> Deposit 
<input type="radio" name="trans" 
value="withdrawal"> Withdrawal<br> 
<input type="submit" value="Submit"> 
</form> 
</body> 
</html> 
<?php 
if ($_POST) { 
$acc1 = $_POST["acc"]; 
$amnt1 = $_POST["amnt"]; 
$trans1 = $_POST["trans"]; 
$con = pg_connect("host=localhost 
dbname=college user=postgres 
password=root"); 
if ($con) { 
echo "Successfully Connected..."; 
if ($trans1 == "deposit") { 
$qry = "UPDATE bank SET balance = 
(SELECT balance FROM bank WHERE 
accno=$acc1) + $amnt1 WHERE
accno=$acc1"; 
$result = pg_query($con, $qry); 
} else { 
$qry = "UPDATE bank SET balance = 
(SELECT balance FROM bank WHERE 
accno=$acc1) - $amnt1 WHERE 
accno=$acc1"; 
$result = pg_query($con, $qry); 
} 
if ($result) { 
echo "Database Updated..."; 
} else { 
echo "Error updating the database."; 
} 
} else { 
echo "Not Connected"; 
} 
} 
?>