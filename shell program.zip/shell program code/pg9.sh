echo -n "enter the no of terms:"
read n
f1=0
f2=1
i=2
echo "the $n terms of febinnoci series are:"
echo "$f1"
echo "$f2"
while [ $i -lt $n ]
do
i=`expr $i + 1`
fn=`expr $f1 + $f2`
echo "$fn"
f1=$f2
f2=$fn
done
