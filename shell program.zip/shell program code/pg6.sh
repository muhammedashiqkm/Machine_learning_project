echo -n "enter a number:"
read n
rem=0
sum=0
while [ $n -gt 0 ]
do
rem=$(( $n % 10 ))
n=$(( $n /10 ))
sum=$(( $sum + $rem ))
done
echo "sum=$sum"
