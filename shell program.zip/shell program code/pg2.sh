echo -n "enter a number:"
read n
if [ $(( $n % 2 )) -eq 0 ]
then
echo "enterd number is even"
else
echo "enterd number is odd"
fi
