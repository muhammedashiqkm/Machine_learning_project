echo -n "enter the radius:"
read r
echo -n "area of the circle is: "
echo "3.14 *$r*$r"|bc

