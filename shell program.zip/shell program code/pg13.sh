echo -n "Enter File Name: "
read filename
if [ ! -f "$filename" ]; then
    echo "File not found: $filename"
    exit 1
fi

contents=$(cat "$filename")
uppercase=$(echo "$contents" | tr '[:lower:]' '[:upper:]')
echo "$uppercase" > "$filename"
echo "File contents successfully converted to uppercase"
