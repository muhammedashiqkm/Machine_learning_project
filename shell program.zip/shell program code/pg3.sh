echo "enter the first number:"
read n1
echo "enter the second number:"
read n2
echo "....menu....."
echo "1.addition"
echo "2.substaction"
echo "3.multiplication"
echo "4.division"
echo "enter the choice"
read ch
case "$ch" in
"1") echo -n "sum="
echo "$n1 + $n2"|bc ;;
"2") echo -n "difference="
echo "$n1 - $n2"|bc ;;
"3") echo -n "product="
echo "$n1 * $n2"|bc ;;
"4") echo -n "division="
echo " $n1 % $n2"|bc ;;
esac
