echo -n "Enter the string:"
read s
echo $s>temp
reverse="$(rev temp)"
echo "Reverse of the entered string is $reverse"
if [ $s = $reverse ]
then
echo "it is palindrome"
else
echo "it is not a Palindrome"
fi
