
echo -n "Enter a string: "
read str

vowels=0
consonants=0
numbers=0

# Convert string to lowercase
str=$(echo "$str" | tr '[:upper:]' '[:lower:]')

# Loop through each character
for (( i=0; i<${#str}; i++ )); do
    ch=${str:$i:1}
    if [[ "$ch" =~ [aeiou] ]]; then
        ((vowels++))
    elif [[ "$ch" =~ [bcdfghjklmnpqrstvwxyz] ]]; then
        ((consonants++))
    elif [[ "$ch" =~ [0-9] ]]; then
        ((numbers++))
    fi
done

echo "Vowels=$vowels"
echo "Consonants=$consonants"
echo "Numbers=$numbers"
