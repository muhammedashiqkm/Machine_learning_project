echo -n "Enter Basic Pay: "
read basic

da=$((basic * 40 / 100))
hra=$((basic * 20 / 100))
gross=$((basic + da + hra))

echo "Gross Salary = $gross"
