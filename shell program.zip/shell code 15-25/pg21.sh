echo -n "Enter file or directory name: "
read item

if [ -e "$item" ]; then
    echo "$item exists"

    if [ -f "$item" ]; then
        echo "$item is a regular file"
    elif [ -d "$item" ]; then
        echo "$item is a directory"
    fi

    if [ -r "$item" ]; then
        echo "$item is readable"
    fi

    if [ -w "$item" ]; then
        echo "$item is writable"
    fi

    if [ -x "$item" ]; then
        echo "$item is executable"
    fi

    if [ -s "$item" ]; then
        echo "$item is not empty"
    else
        echo "$item is empty"
    fi
else
    echo "$item does not exist"
fi
