
echo "Select an operation:"
echo "1. Display file content"
echo "2. List files in directory"
echo "3. Create a directory"
echo "4. Copy a file"
echo "5. Rename a file"
echo "6. Delete a file"

read -p "Enter your choice: " choice

case $choice in
    1) read -p "Enter file name: " file
       cat "$file"
       ;;
    2) read -p "Enter directory name: " dir
       ls "$dir"
       ;;
    3) read -p "Enter directory name: " dir
       mkdir "$dir"
       echo "Directory created"
       ;;
    4) read -p "Enter source file: " src
       read -p "Enter destination file: " dest
       cp "$src" "$dest"
       echo "File copied"
       ;;
    5) read -p "Enter current filename: " old
       read -p "Enter new file name: " new
       mv "$old" "$new"
       echo "File renamed"
       ;;
    6) read -p "Enter file name to delete: " file
       rm "$file"
       echo "File deleted"
       ;;
    *) echo "Invalid choice"
       ;;
esac
