
sum=0
count=$#

for num in "$@"; do
    sum=$((sum + num))
done

if [ $count -gt 0 ]; then
    avg=$((sum / count))
    echo "Average = $avg"
else
    echo "No numbers provided"
fi
