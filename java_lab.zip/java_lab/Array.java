import java.util.*;

public class Array {
    public static void main(String[] args) {
        int i, j, t, n;

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        n = sc.nextInt();

        // Ensure valid array size
        if (n < 2) {
            System.out.println("Array should have at least two elements.");
            return;
        }

        int arr[] = new int[n];

        System.out.println("Enter the elements of array:");
        for (i = 0; i < n; i++) { // ✅ Fix input loop
            arr[i] = sc.nextInt();
        }

        // Sorting array using Bubble Sort
        for (i = 0; i < n - 1; i++) {
            for (j = i + 1; j < n; j++) {
                if (arr[i] > arr[j]) { // ✅ Fix sorting logic
                    t = arr[i];
                    arr[i] = arr[j];
                    arr[j] = t;
                }
            }
        }

        System.out.println("Smallest Number is: " + arr[0]);
        System.out.println("Largest Number is: " + arr[n - 1]);
        System.out.println("Second largest element: " + arr[n - 2]);

        sc.close();
    }
}
