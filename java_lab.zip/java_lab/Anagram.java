import java.util.*;

class Anagram {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean flag = false;
        String string1, string2;
        System.out.println("Enter first string:");
        string1 = sc.nextLine();
        System.out.println("Enter second string:");
        string2 = sc.nextLine();

        // Remove all spaces
        string1 = string1.replaceAll("\\s", "");
        string2 = string2.replaceAll("\\s", "");

        // Compare lengths first
        if (string1.length() == string2.length()) {
            // Convert strings to lowercase, then to char arrays
            char[] s1 = string1.toLowerCase().toCharArray();
            char[] s2 = string2.toLowerCase().toCharArray();

            // Sort the character arrays
            Arrays.sort(s1);
            Arrays.sort(s2);

            // Compare the sorted arrays
            flag = Arrays.equals(s1, s2);
        }

        // Output result
        if (flag) {
            System.out.println("Strings are anagrams.");
        } else {
            System.out.println("Strings are not anagrams.");
        }

        sc.close(); // Close scanner
    }
}
