import java.util.*;
public class Hcm {
    public static void main(String[] args) {
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enetr Two numbers");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int x=a;
        int y=b;
        while (y!=0) {
            int t=y;
            y=x%y;
            x=t;
            
        }
        int hcm=x;
        int lcm=(a*b)/hcm;

        System.out.println("hcf:"+hcm);
        System.out.println("lcm"+lcm);


    }
    
}
