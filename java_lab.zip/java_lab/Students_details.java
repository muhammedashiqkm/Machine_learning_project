import java.util.Scanner;

class student{
    String name;
    int rollno;

    void readStudent_details(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name:");
        name = sc.nextLine();
        System.out.println("Enter roll no:");
        rollno = sc.nextInt();
    }
    void displayStudent_details(){
        System.out.println("Name:"+name);
        System.out.println("Roll no:"+rollno);
    }
}
class Marks extends student{

int[] marks = new int[5];
int total = 0;
double avg;

void readMarks(){

    for(int i=0;i<5;i++){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter marks" +(i+1));
        marks[i] = sc.nextInt();
        total += marks[i];
        
    }
    avg = total/5.0;
}
void displayMarks(){
    System.out.println("total marks:"+total);
    System.out.println("average marks:"+avg);

}
}
public class Students_details{
    public static void main(String[] args) {
        student s = new student();
        s.readStudent_details();
        s.displayStudent_details();
        Marks m = new Marks();
        m.readMarks();
        m.displayMarks();
        
    }
}