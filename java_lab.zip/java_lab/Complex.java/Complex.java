import java.util.Scanner;

public class Complex {
    int real, img;

    // Method to read a complex number
    public void readComplex(Scanner sc) {
        System.out.print("Enter real part: ");
        real = sc.nextInt();
        System.out.print("Enter imaginary part: ");
        img = sc.nextInt();
    }

    // Method to add two complex numbers
    public Complex sum(Complex c) {
        Complex result = new Complex();
        result.real = this.real + c.real;
        result.img = this.img + c.img;
        return result;
    }

    // Method to display the complex number in proper format
    public void display() {
        if (img >= 0)
            System.out.println(real + " + " + img + "i");
        else
            System.out.println(real + " - " + (-img) + "i");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // Use a single Scanner object
        Complex c1 = new Complex();
        Complex c2 = new Complex();

        c1.readComplex(sc);
        c2.readComplex(sc);

        Complex c3 = c1.sum(c2);
        System.out.print("Sum of complex numbers: ");
        c3.display();

        sc.close(); // Close Scanner to prevent resource leak
    }
}
