import java.util.Scanner;
class Shape_volume{
    double v;
    void volume(double a){
        v=a*a*a;
        System.out.println("volume of cube:"+v);
    }
    void volume(double l,double h,double b ){
        v=l*h*b;
        System.out.println("volume of rectangular box:"+v);
    }
    void volume(double r,double h){
        v=3.14*r*r*h;
        System.out.println("volume of cylinder:"+v);
    }
}

public class ShapeVolumeMain {
    public static void main(String[] args) {
        Shape_volume s = new Shape_volume();
        double a,l,b,h,r;
        Scanner sc = new Scanner(System.in);
        System.out.println("Cube:....");
        System.out.println("Enter the side of cube");
        a= sc.nextDouble();
        s.volume(a);
        System.out.println("Rectangular_Box:....");
        System.out.println("Enter the height,breadth and length");
        h= sc.nextDouble();
        l= sc.nextDouble();
        b= sc.nextDouble();
        s.volume(l,h,b);
        System.out.println("Cylinder:....");
        System.out.println("Enter the radius and height");
        r= sc.nextDouble();
        h= sc.nextDouble();
        s.volume(r,h);


        
    }
}
