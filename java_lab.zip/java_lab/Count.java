public class Count{
    static int count =0;
    Count(){
        count++;
    }
    Count(int n){
        Count[] ob=new Count[n];
        for(int i=0;i<n;i++){
            ob[i]=new Count();
        }
    }
    public static void main(String[] args) {
        Count c1 = new Count();
        Count c2 = new Count(5);
        System.out.println("Count: " + Count.count);
    }
}

            
        
