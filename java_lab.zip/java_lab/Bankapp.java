class miniBalexp extends Exception {
    public miniBalexp(String message) {
        super(message);
    }
}

class Account {
    private String accno;
    private String name;
    private double balance; // Change from Double to double (primitive type)

    public Account(String accno, String name, double balance) { // Change Double to double
        this.accno = accno;
        this.name = name;
        this.balance = balance;
    }

    public void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid deposit amount");
        } else {
            balance += amount;
            System.out.println("Deposited: " + amount);
            System.out.println("Updated Balance: " + balance);
        }
    }

    public void Withdraw(double amount) throws miniBalexp {
        if (amount > balance) {
            throw new miniBalexp("Insufficient Balance");
        } else if (amount <= 0) {
            System.out.println("Invalid withdrawal amount");
        } else {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
            System.out.println("Updated Balance: " + balance);
        }
    }

    public double getBalance() { // Change from Double to double
        return balance;
    }
}

public class Bankapp {
    public static void main(String[] args) {
        Account myAccount = new Account("12345", "John Doe", 1000.0); // This will now match the constructor

        myAccount.deposit(500.0);

        try {
            myAccount.Withdraw(200.0); // Exception handling
        } catch (miniBalexp e) {
            System.out.println("Exception: " + e.getMessage());
        }

        System.out.println("Current Balance: " + myAccount.getBalance());
    }
}
