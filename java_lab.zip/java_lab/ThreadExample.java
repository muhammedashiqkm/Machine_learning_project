class OddThread implements Runnable {
    private int limit;

    OddThread(int limit) {
        this.limit = limit;
    }

    public void run() {
        for (int i = 1; i <= limit; i += 2) {
            System.out.println("Odd: " + i);
        }
    }
}

class EvenThread implements Runnable {
    private int limit;

    EvenThread(int limit) {
        this.limit = limit;
    }

    public void run() {
        for (int i = 2; i <= limit; i += 2) {
            System.out.println("Even: " + i);
        }
    }
}

public class ThreadExample { 
    public static void main(String[] args) {
        int limit = 10;

        Thread oddThread = new Thread(new OddThread(limit));
        Thread evenThread = new Thread(new EvenThread(limit));

        oddThread.start();
        evenThread.start();
    }
}
