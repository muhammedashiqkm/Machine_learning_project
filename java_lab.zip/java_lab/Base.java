import java.util.*;

public class Base {
    public static void main(String[] args) {
        int n;
        String bin,oct,hex;
        Scanner sc=new Scanner(System.in);
        System.out.println("enetr the integer");
        n=sc.nextInt();
        bin=Integer.toString(n,2);
        oct=Integer.toString(n,8);
        hex=Integer.toString(n,16);

        System.out.println("bianry:"+bin);
        System.out.println("oct:"+oct);
        System.out.println("hex:"+hex);



    }
}
