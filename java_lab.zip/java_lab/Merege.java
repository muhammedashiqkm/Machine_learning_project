import java.util.*;
public class Merege {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int m,n,i,index=0;
        System.out.println("eneter the length of first array");
        m=sc.nextInt();
        int a[]=new int[m];
        System.out.println("Enetr the elements of first Array");
        for(i=0;i<m;i++){
            a[i]=sc.nextInt();
        }
        System.out.println("eneter the length of second array");
        n=sc.nextInt();
        int b[]=new int[n];
        System.out.println("Enetr the elements of first Array");
        for(i=0;i<n;i++){
            b[i]=sc.nextInt();
        }
        int c[]=new int[m+n];

        for (i=0;i<m; i++) {
            c[index++]=a[i];
       }

       for(i=0;i<n;i++){
            c[index++]=b[i];

       }

       System.out.println("meregd arra is");
       for(i=0;i<c.length;i++){
        System.out.println(c[i]);
       }

       

    }
}
