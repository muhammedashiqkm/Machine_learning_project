import java.awt.*;
import java.awt.event.*;

public class ListBoxApp extends Frame implements ActionListener {
    List list;
    TextField textField;
    Button addButton, removeButton;

    public ListBoxApp() {
        // Set layout
        setLayout(new FlowLayout());

        // Initialize components
        list = new List(10);
        textField = new TextField(20);
        addButton = new Button("Add");
        removeButton = new Button("Remove");

        // Add components to frame
        add(textField);
        add(addButton);
        add(removeButton);
        add(list);

        // Add action listeners
        addButton.addActionListener(this);
        removeButton.addActionListener(this);

        // Configure frame
        setTitle("AWT List Box Example");
        setSize(300, 300);
        setVisible(true);

        // Handle window closing event
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            String item = textField.getText().trim();
            if (!item.isEmpty()) {
                list.add(item);
                textField.setText("");
            }
        } else if (e.getSource() == removeButton) {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex >= 0) {
                list.remove(selectedIndex);
            }
        }
    }

    public static void main(String[] args) {
        new ListBoxApp();
    }
}
