import java.sql.*;

public class EmployeeJDBC {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/your_database"; // Change to your database
        String user = "your_username";
        String password = "your_password";

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, password);
            Statement stmt = conn.createStatement();

            // Create employee table if not exists
            String createTableSQL = "CREATE TABLE IF NOT EXISTS employee (" +
                    "id INT PRIMARY KEY AUTO_INCREMENT, " +
                    "name VARCHAR(50), " +
                    "design VARCHAR(50), " +
                    "dept VARCHAR(50))";
            stmt.executeUpdate(createTableSQL);
            System.out.println("Table created successfully.");

            // Insert records
            String insertSQL = "INSERT INTO employee (name, design, dept) VALUES " +
                    "('John Doe', 'Software Engineer', 'IT')," +
                    "('Jane Smith', 'Project Manager', 'HR')," +
                    "('Alice Brown', 'Data Analyst', 'Finance')";
            stmt.executeUpdate(insertSQL);
            System.out.println("Records inserted successfully.");

            // Retrieve and display records
            String selectSQL = "SELECT * FROM employee";
            ResultSet rs = stmt.executeQuery(selectSQL);
            
            System.out.println("\nEmployee Details:");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + ", Name: " + rs.getString("name") +
                        ", Designation: " + rs.getString("design") + ", Department: " + rs.getString("dept"));
            }

            // Close connections
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
