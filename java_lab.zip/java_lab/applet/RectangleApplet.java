package applet;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

public class RectangleApplet extends Applet {
    private int x, y, width, height;
    private Color rectColor;

    // Initialize the applet
    @SuppressWarnings("removal")
    public void init() {
        // Get parameters from the HTML file
        x = Integer.parseInt(getParameter("x"));
        y = Integer.parseInt(getParameter("y"));
        width = Integer.parseInt(getParameter("width"));
        height = Integer.parseInt(getParameter("height"));

        // Get the color parameter and convert it to a Color object
        String colorParam = getParameter("color");
        rectColor = Color.decode(colorParam);
    }

    // Paint the rectangle
    public void paint(Graphics g) {
        g.setColor(rectColor); // Set the color
        g.fillRect(x, y, width, height); // Draw the rectangle
    }
}
//javac RectangleApplet.java
//appletviewer Applet.html
/*import javax.swing.*;
import java.awt.*;

public class RectangleSwing extends JFrame {
    private int x, y, width, height;
    private Color rectColor;

    public RectangleSwing() {
        setTitle("Rectangle Drawing");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set rectangle properties (same as applet parameters)
        x = 50;
        y = 100;
        width = 200;
        height = 150;
        rectColor = Color.RED; // #FF0000 in hex

        setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g); // Call JFrame's paint method
        g.setColor(rectColor);
        g.fillRect(x, y, width, height);
    }

    public static void main(String[] args) {
        new RectangleSwing(); // Run the program
    }
}
 */
