import java.applet.Applet;
import java.awt.*;

// Extend the Applet class
public class RectangleApplet extends Applet {
    int x, y, width, height;
    Color rectColor;

    // Initialize method
    public void init() {
        // Get parameters from the HTML file
        x = Integer.parseInt(getParameter("x"));
        y = Integer.parseInt(getParameter("y"));
        width = Integer.parseInt(getParameter("width"));
        height = Integer.parseInt(getParameter("height"));

        // Get color from parameter
        String colorParam = getParameter("color").toLowerCase();

        // Convert string to Color object
        switch (colorParam) {
            case "red":
                rectColor = Color.RED;
                break;
            case "blue":
                rectColor = Color.BLUE;
                break;
            case "green":
                rectColor = Color.GREEN;
                break;
            case "yellow":
                rectColor = Color.YELLOW;
                break;
            default:
                rectColor = Color.BLACK; // Default color
        }
    }

    // Paint method to draw rectangle
    public void paint(Graphics g) {
        g.setColor(rectColor);
        g.fillRect(x, y, width, height);
    }
}
