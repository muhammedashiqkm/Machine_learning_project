import java.util.*;

public class Trace {
    public static void main(String[] args) {
        int i, j, n;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter order of the square matrix:");
        n = sc.nextInt();
        
        int[][] a = new int[n][n];
        int[][] t = new int[n][n];

        System.out.println("Enter the elements of the matrix:");
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                a[i][j] = sc.nextInt();
            }
        }

        // Compute Transpose (Fix: Move it after input loop)
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                t[i][j] = a[j][i];
            }
        }

        // Compute Trace
        int s = 0;
        for (i = 0; i < n; i++) {
            s += a[i][i];
        }

        // Display Original Matrix
        System.out.println("Matrix A:");
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }

        // Display Transpose Matrix
        System.out.println("Transpose of Matrix A:");
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                System.out.print(t[i][j] + " ");
            }
            System.out.println();
        }

        // Display Trace
        System.out.println("Trace of Matrix A: " + s);

        sc.close();
    }
}
