class Calculator {
    public static void main(String[] args) {
        int a, b, s, d, p, q, r;
        a = Integer.parseInt(args[0]);
        b = Integer.parseInt(args[1]);
        s = a + b;
        d = a - b;
        p = a * b;
        q = a / d;
        r = a % d;
        System.out.println("sum=" + s);
        System.out.println("diffrence" + d);
    }
}

//PS D:\java_lab> javac Calculator.java 
//PS D:\java_lab> java Calculator 10 5