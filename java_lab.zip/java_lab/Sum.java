import java.util.*;

public class Sum {
    int[] rev = new int[10];  // Stores reversed digits
    int n, r, sum = 0, x, index = 0;

    public void Sumrev() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number:");
        n = sc.nextInt();
        x = n;
        sc.close();  // Closing scanner after input

        while (x > 0) {
            r = x % 10;  // Extract last digit
            sum += r;  // Add to sum
            rev[index++] = r;  // Store in reverse order
            x = x / 10;  // Remove last digit
    }
    }
    public void display() {
        System.out.println("Sum of digits is: " + sum);

        System.out.print("Reverse of the number is: ");
        for (int i = 0; i < index; i++) {  // Print only valid digits
            System.out.print(rev[i]);
        }
        System.out.println();  // Print newline
    }

    public static void main(String[] args) {
        Sum obj = new Sum();
        obj.Sumrev();
        obj.display();
    }
}
