import java.util.Scanner;
class Vowels{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string:");
        String s = sc.nextLine();
        String v[]={"a","e","i","o","u","A","E","I","O","U"};
        String r=s;
        for(int i=0 ;i<s.length();i++){
            r=r.replaceAll(v[i],"");
        }
        System.out.println("Vowels removed:"+r);
    }
}