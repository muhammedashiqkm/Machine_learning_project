import java.util.Scanner;

// Abstract Base Class
abstract class Shape {
    abstract void area();
}

// 2D Shape Abstract Class
abstract class TwoDim extends Shape {}

// 3D Shape Abstract Class
abstract class ThreeDim extends Shape {}

// Square Class
class Square extends TwoDim {
    double side;

    Square(double side) {
        this.side = side;
    }

    @Override
    void area() {
        double area = side * side;
        System.out.println("Area of square: " + area);
    }
}

// Triangle Class
class Triangle extends TwoDim {
    double height, base;

    Triangle(double height, double base) {
        this.height = height;
        this.base = base;
    }

    @Override
    void area() {
        double area = 0.5 * base * height;
        System.out.println("Area of triangle: " + area);
    }
}

// Sphere Class
class Sphere extends ThreeDim {
    double radius;

    Sphere(double radius) {
        this.radius = radius;
    }

    @Override
    void area() {
        double area = 4 * Math.PI * radius * radius;
        System.out.println("Surface area of sphere: " + area);
    }
}

// Cube Class
class Cube extends ThreeDim {
    double side;

    Cube(double side) {
        this.side = side;
    }

    @Override
    void area() {
        double area = 6 * side * side;
        System.out.println("Surface area of cube: " + area);
    }
}

// Main Class
public class ShapeAreaCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Square
        System.out.print("Enter the side of square: ");
        double side = sc.nextDouble();
        Square s = new Square(side);
        s.area();

        // Triangle
        System.out.print("Enter the height and base of triangle: ");
        double height = sc.nextDouble();
        double base = sc.nextDouble();
        Triangle t = new Triangle(height, base);
        t.area();

        // Sphere
        System.out.print("Enter the radius of sphere: ");
        double radius = sc.nextDouble();
        Sphere sp = new Sphere(radius);
        sp.area();

        // Cube
        System.out.print("Enter the side of cube: ");
        double cubeSide = sc.nextDouble();
        Cube cu = new Cube(cubeSide);
        cu.area();

        sc.close(); // Close scanner to prevent resource leak
    }
}
