import java.util.Scanner;

// User-defined Exception for Minimum Balance Violation
class MinBalExp extends Exception {
    public MinBalExp(String message) {
        super(message);
    }
}

// Bank Account Class
class Account {
    private double balance;

    // Constructor to initialize balance
    public Account(double initialBalance) {
        this.balance = initialBalance;
    }

    // Method to deposit money
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
            System.out.println("Updated Balance: " + balance);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    // Method to withdraw money with exception handling
    public void withdraw(double amount) throws MinBalExp {
        if (amount > balance) {
            throw new MinBalExp("Insufficient Balance! Withdrawal amount exceeds current balance.");
        } else {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
            System.out.println("Updated Balance: " + balance);
        }
    }

    // Method to check balance
    public double getBalance() {
        return balance;
    }
}

// Main Class
public class BankTransaction {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter initial balance: ");
        double initialBalance = sc.nextDouble();

        // Create an Account object
        Account myAccount = new Account(initialBalance);

        while (true) {
            System.out.println("\n1. Deposit\n2. Withdraw\n3. Check Balance\n4. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter deposit amount: ");
                    double depositAmount = sc.nextDouble();
                    myAccount.deposit(depositAmount);
                    break;

                case 2:
                    System.out.print("Enter withdrawal amount: ");
                    double withdrawAmount = sc.nextDouble();
                    try {
                        myAccount.withdraw(withdrawAmount);
                    } catch (MinBalExp e) {
                        System.out.println("Exception: " + e.getMessage());
                    }
                    break;

                case 3:
                    System.out.println("Current Balance: " + myAccount.getBalance());
                    break;

                case 4:
                    System.out.println("Exiting... Thank you!");
                    sc.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
