import java.util.*;

public class Triangle {
    public static void main(String[] args) {
        float a, b, c;
        double s, area;
        Scanner sc = new Scanner(System.in);
        System.out.println("first side:");
        a = sc.nextFloat();
        System.out.println("second side:");
        b = sc.nextFloat();
        System.out.println("third side:");
        c = sc.nextFloat();

        if (a > (b + c) || b > (a + c) || c > (a + b))
            System.out.println("cannot form triangele");
        else {
            if (a == b && b == c && c == a)
                System.out.println("triangele is equilateral");
            else if (a == b || b == c || c == a)
                System.out.println("triangele is isosles");
            else
                System.out.println("scalane");
            s = (a + b + c) / 2;
            area = Math.sqrt(s * (s - a) * (s - b) * (s - c));
            System.out.println("area:" + area);
        }

    }
}
