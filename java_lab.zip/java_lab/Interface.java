import java.util.Scanner;

interface Volume {
    double pi = Math.PI;  // Constant in interface
    void readdata(); // Method signature
    double display(); // Method signature
}

// Sphere Class
class Sphere implements Volume {
    double radius; 

    public void readdata() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter radius of Sphere: ");
        radius = sc.nextDouble();
    }

    public double display() {
        return (4.0 / 3.0) * pi * radius * radius * radius; // Corrected volume formula
    }
}

// Cylinder Class
class Cylinder implements Volume {
    double radius, height; // Class-level variables

    public void readdata() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter radius of Cylinder: ");
        radius = sc.nextDouble();
        System.out.print("Enter height of Cylinder: ");
        height = sc.nextDouble();
    }

    public double display() {
        return pi * radius * radius * height;
    }
}

// Main Class
public class Interface { // Changed class name to avoid conflict with Java keywords
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Sphere
        Sphere s = new Sphere();
        s.readdata();
        System.out.println("Volume of Sphere: " + s.display());

        // Cylinder
        Cylinder c = new Cylinder();
        c.readdata();
        System.out.println("Volume of Cylinder: " + c.display());

        sc.close(); // Close Scanner
    }
}
